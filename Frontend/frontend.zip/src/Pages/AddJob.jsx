
import JobForm from '../Components/JobForm'

const AddJob = () => {

    
    return (
        <JobForm state="ایجاد"/>
    )
}

export default AddJob